const express = require('express');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const  dotenv = require('dotenv');
const mongoose = require('mongoose');
const {Schema} = mongoose;
const cookieSession = require('cookie-session');
const bodyParser = require('body-parser');
const QrCode = require('qrcode');

dotenv.config();

const stuCheck = (req, res, next) => {
    if(!req.user){
        res.redirect('/');
    }else if(req.user.role !== 'Student'){
        res.redirect('/noAuth');
    }else{
        next();
    }
};



const app = express();
mongoose.connect(`mongodb+srv://valantamildasan:${process.env.SEC}@outpass.rlazwv1.mongodb.net/StudentDet`);


app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));
app.use(bodyParser.json());
// const studentSchema = new Schema({

//     username : String,
//     googleId : String,
//     dep : String,
//     sec : String,
//     year : String,
//     sem : String,
//     regNo : String,
//     purpose : String,
//     stuMobile : Number,
//     vrequested : Number,
//     vaccepted : Number,
//     outDate: String,
//     InDate : String,
//     parMobile : String,
//     email:String,
//     adAccepted:Number,
//     hodAccepted : Number

// });

const userSchema = new Schema({
    username : String,
    email : String,
    googleID : String,
    role : String,
    dep : String,
    sec : String,
    year : String,
    sem : String,
    regNo : String,
    purpose : String,
    stuMobile : Number,
    vrequested : Number,
    vaccepted : Number,
    outDate: String,
    outTime : String,
    inDate : String,
    inTime : String,
    parMobile : String,
    email:String,
    adAccepted:Number,
    hodAccepted : Number,
    college:String
});

const wardenSchema = new Schema({
    username : String,
    email : String,
    googleID : String
});

const User = mongoose.model('user',userSchema);



const Warden = mongoose.model('warden',wardenSchema);

app.use(bodyParser.json());
app.use(cookieSession({
    maxAge: 24 * 60 * 60 * 1000,
    keys: [`${process.env.cookie}`]
}));

app.use(passport.initialize());
app.use(passport.session());    

passport.serializeUser((user, done) => {
    done(null, user.id);
});

passport.deserializeUser((id, done) => {
    User.findById(id).then((user) => {
        done(null, user);
    });
});



app.post('/submit',stuCheck,(req,res)=>{
  
    const datetimeInput = req.body.inDate;
    const dateTime = new Date(datetimeInput);
    const formattedDate = dateTime.toISOString().split('T')[0];
    const formattedTime = dateTime.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: 'numeric',
        hour12: true
    });

    const odatetimeInput = req.body.outDate;
    const odateTime = new Date(odatetimeInput);
    const oformattedDate = odateTime.toISOString().split('T')[0];
    const oformattedTime = odateTime.toLocaleTimeString('en-US', {
        hour: 'numeric',
        minute: 'numeric',
        hour12: true
    });

    User.findOneAndUpdate({_id:req.user._id},  {        
    
    
    outDate : req.body.outDate,
    inDate : formattedDate,
    inTime : formattedTime,
    outDate : oformattedDate,
    outTime : oformattedTime,
    stuMobile : req.body.stuMobile,
    parMobile : req.body.parMobile,
    vrequested : 1,
    vaccepted : 0,
    adAccepted:0,
    hodAccepted:0,
    purpose : req.body.purpose
    }).then(()=>{
        console.log('Submited');
        res.redirect('/showStatus');
    }).catch((err)=>{
        console.log(err);
    });
    
    
});

passport.use(new GoogleStrategy({
    clientID : process.env.clientID,
    clientSecret : process.env.clientSecret,
    callbackURL : "/auth/google/redirect",
    
    },
    function(accessToken, refreshToken, profile, done) {
        User.findOne({email: profile._json.email}).then((currentUser) => {
                if(currentUser){
                    done(null, currentUser);
                }else{
                    done(null, false);
                }
                });
              

      }
    ));

app.get('/auth/google/redirect',passport.authenticate('google',{
    scope:['profile','email'],failureRedirect : '/noAuth'
}),(req,res)=>{
    if(req.user.role == 'Student'){
        res.redirect('/home');
    }
    
    else{
        if(req.user.role == 'Teacher'){
            res.redirect('/teacherHome');
        }else if(req.user.role == 'Warden'){
            res.redirect('/wardenHome');
        }else if(req.user.role == 'Hod'){
            res.redirect('/hodHome');
        }else{
            res.redirect('/mic');
        }
    }
    
}
);

app.get('/home',stuCheck,(req,res)=>{
    
    res.render('homePage.ejs');
});

app.get('/requestForm',stuCheck,(req,res)=>{
    
    if(!req.user.vrequested || req.user.vrequested == 0){
        res.render('requestForm.ejs',{user : req.user});
    }else{
        res.redirect('/showStatus');
    }
    
});

app.get('/showStatus',stuCheck,(req,res)=>{
    
    if( !req.user.vrequested || req.user.vrequested == 0){
        res.redirect('/requestForm');
    }
    else{
        
        if(req.user.vaccepted == 1 && req.user.adAccepted == 1 && req.user.hodAccepted == 1 ){
            QrCode.toDataURL(`${req.user.id}`,(err,string)=>{
            
                res.render('showStatus.ejs',{wstatus : req.user.vaccepted,adStatus : req.user.adAccepted,hodStatus : req.user.hodAccepted,t:string});
            
            });
        }else{
            res.render('showStatus.ejs',{wstatus : req.user.vaccepted,adStatus : req.user.adAccepted,hodStatus : req.user.hodAccepted});
        }
        

        
    }
});

app.get("/noAuth",(req,res)=>{
    res.render('noAuth.ejs');
});

app.get('/',(req,res)=>{
    
    if(req.user){
        if(req.user.role == 'Student'){
            res.redirect('/home');
        }else{
            res.redirect('/noAuth');
        }
        
    }else{
        res.render('studentLogin.ejs');
    }
    
});

app.get('/logout', (req, res) => {
    req.logout();
    res.redirect('/');
});






app.get('/tutorLogin',(req,res)=>{
    res.render('tutorLogin.ejs');
});

app.get('/teacherHome',(req,res)=>{
    User.find({role : "Student",vrequested : 1,adAccepted : 0,dep : req.user.dep,sec : req.user.sec,year:req.user.year}).then((arr)=>{
        res.render('teacherHome.ejs',{arr});
       }).catch((err)=>{
        console.log(err);
       })
  
});

app.post("/acceptOneTeacher",(req,res)=>{
  
    User.findByIdAndUpdate(req.body.accept,{adAccepted : 1}).then((arr)=>{
        
        res.redirect("/teacherHome");

       }).catch((err)=>{
        console.log(err);
       });
});

app.post('/declineOneTeacher',(req,res)=>{

    User.findByIdAndUpdate(req.body.decline,{adAccepted : -1}).then((arr)=>{
        
        res.redirect("/teacherHome");

       }).catch((err)=>{
        console.log(err);
       });
});

app.post('/acceptAllTeacher',(req,res)=>{
    User.updateMany({role : 'Student',dep : req.user.dep,sec:req.user.sec,vrequested:1,adAccepted : 0,year:req.user.year},{adAccepted:1}).then((arr)=>{
        res.redirect('/teacherHome');
    }).catch((err)=>{
        console.log(err);
    });
});

app.post('/declineAllTeacher',(req,res)=>{
    User.updateMany({role:'Student',dep : req.user.dep,sec:req.user.sec,vrequested:1,adAccepted : 0,year:req.user.year},{adAccepted : -1}).then((arr)=>{
        res.redirect('/teacherHome');
    }).catch((err)=>{
        console.log(err);
    });
});




app.get('/hodLogin',(req,res)=>{
    res.render('hodLogin.ejs');
});

app.get('/hodHome',(req,res)=>{

    User.find({role : "Student",vrequested : 1,adAccepted : 1,hodAccepted : 0,dep : req.user.dep,year:req.user.year}).then((arr)=>{
        res.render('hodHome.ejs',{arr});
       }).catch((err)=>{
        console.log(err);
       });
  
});

app.post("/acceptOneHod",(req,res)=>{
  
    User.findByIdAndUpdate(req.body.accept,{hodAccepted : 1}).then((arr)=>{
        
        res.redirect("/hodHome");

       }).catch((err)=>{
        console.log(err);
       });
});

app.post('/declineOneHod',(req,res)=>{

    User.findByIdAndUpdate(req.body.decline,{hodAccepted : -1}).then((arr)=>{
        
        res.redirect("/hodHome");

       }).catch((err)=>{
        console.log(err);
       });
});

app.post('/acceptAllHod',(req,res)=>{
    User.updateMany({role : 'Student',dep : req.user.dep,vrequested:1,adAccepted : 1,hodAccepted : 0,year:req.user.year},{hodAccepted:1}).then((arr)=>{
        res.redirect('/hodHome');
    }).catch((err)=>{
        console.log(err);
    });
});

app.post('/declineAllHod',(req,res)=>{
    User.updateMany({role : "Student",dep : req.user.dep,sec:req.user.sec,vrequested:1,adAccepted : 0,year:req.user.year},{adAccepted : -1}).then((arr)=>{
        res.redirect('/hodHome');
    }).catch((err)=>{
        console.log(err);
    });
});


app.get('/wardenLogin',(req,res)=>{
    res.render('wardenLogin.ejs');
});

app.get('/wardenHome',(req,res)=>{
    
    User.find({role : "Student",vrequested : 1,adAccepted : 1,hodAccepted : 1,vaccepted : 0}).then((arr)=>{
        res.render('wardenHome.ejs',{arr});
       }).catch((err)=>{
        console.log(err);
       });
  
});

app.post("/acceptOneWarden",(req,res)=>{
  
    User.findByIdAndUpdate(req.body.accept,{vaccepted : 1}).then((arr)=>{
        
        res.redirect("/wardenHome");

       }).catch((err)=>{
        console.log(err);
       });
});

app.post('/declineOneWarden',(req,res)=>{

    User.findByIdAndUpdate(req.body.decline,{vaccepted : -1}).then((arr)=>{
        
        res.redirect("/wardenHome");

       }).catch((err)=>{
        console.log(err);
       });
});

app.post('/acceptAllWarden',(req,res)=>{
    User.updateMany({role : 'Student',vrequested:1,adAccepted : 1,hodAccepted : 1,vaccepted : 0},{vaccepted:1}).then((arr)=>{
        res.redirect('/wardenHome');
    }).catch((err)=>{
        console.log(err);
    });
});

app.post('/declineAllWarden',(req,res)=>{
    User.updateMany({role : "Student",vrequested:1,adAccepted : 1,hodAccepted : 1,vaccepted : 0},{vAccepted : -1}).then((arr)=>{
        res.redirect('/wardenHome');
    }).catch((err)=>{
        console.log(err);
    });
});


app.get('/security',(req,res)=>{
    // User.find({role:"Student",vaccepted:1}).then((arr)=>{
    //     res.render('security.ejs',{arr});
    // }).catch((err)=>{
    //     console.log(err);
    // })
    res.render('security.ejs');
});

let da;

app.get('/securityCheck',(req,res)=>{
    
    res.render('securityStatus.ejs',{status:req.session.flag.status,name : req.session.flag.name});

});

app.post('/securityCheck',(req,res)=>{
    
    User.findById(req.body.data).then((arr)=>{
        
        if(!arr.vaccepted || arr.vaccepted != 1) {
            req.session.flag = {name : '',status:'declined'};
            res.redirect('/securityCheck');
        }else{
            
            req.session.flag = {name:arr.username,status : 'accepted'};
            res.redirect('/securityCheck');
        }
        
    })
    
});



app.listen(3000,(req,res)=>{
    console.log('hosted successfully');
});

