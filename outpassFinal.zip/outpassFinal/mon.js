
const mongoose = require('mongoose');
const {Schema} = mongoose;

mongoose.connect('mongodb://0.0.0.0:27017/StudentDet',{useNewUrlParser:true});


const studentSchema = new Schema({
    username : String,
    googleId : String,
    dep : String,
    sec : String,
    year : String,
    sem : String,
    regNo : String,
    purpose : String,
    stuMobile : Number,
    vrequested : Number,
    vaccepted : Number,
    outDate: String,
    InDate : String,
    parMobile : String,
    email:String,
    adAccepted:Number,
    hodAccepted : Number

});

const userSchema = new Schema({
    username : String,
    email : String,
    googleID : String,
    role : String,
    username : String,
    googleId : String,
    dep : String,
    sec : String,
    year : String,
    sem : String,
    regNo : String,
    purpose : String,
    stuMobile : Number,
    vrequested : Number,
    vaccepted : Number,
    outDate: String,
    InDate : String,
    parMobile : String,
    email:String,
    adAccepted:Number,
    hodAccepted : Number
});

const User = mongoose.model('user',userSchema);


const Student = mongoose.model('student', studentSchema);

const wardenSchema = new Schema({
    username : String,
    email : String,
    googleID : String
});

const Warden = mongoose.model('warden',wardenSchema);


// const val = new User({
//     username : 'Valan',
//     email : 'valantamildasana.cse2022@citchennai.net'
// }).save();

const vala = new User({
    username: "Valan"
}).save();